
# CSAI415 D1 Data Utilities

Contains:
- Chunk and Query dataclasses
- Synthetic corpus generator
- Temporal query stream generator
- Validation helpers
- Pytest tests
